#pragma once
#include <ntddk.h>
#include <windef.h>