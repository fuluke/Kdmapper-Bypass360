#include <dwmapi.h>
#include <comdef.h> 
#include <winioctl.h> 

#define ctl_write   CTL_CODE(FILE_DEVICE_UNKNOWN, 0x0366, METHOD_BUFFERED, FILE_SPECIAL_ACCESS)
#define ctl_read    CTL_CODE(FILE_DEVICE_UNKNOWN, 0x0367, METHOD_BUFFERED, FILE_SPECIAL_ACCESS)
#define ctl_base    CTL_CODE(FILE_DEVICE_UNKNOWN, 0x0368, METHOD_BUFFERED, FILE_SPECIAL_ACCESS)
#define ctl_clear	CTL_CODE(FILE_DEVICE_UNKNOWN, 0x0369, METHOD_BUFFERED, FILE_SPECIAL_ACCESS)

typedef struct info_t {
	int pid = 0;
	void* address;
	void* value;
	SIZE_T size;
	void* data;
}info, * p_info;

void kdmapper_driver_loaded();

void driver_init(void* lpParam);

template <typename Type>
void DriverWrite(HANDLE hDriver, unsigned __int32 ProcessId, unsigned long long int Address, Type stuff)
{
	info_t Input_Output_Data;

	Input_Output_Data.pid = ProcessId;

	Input_Output_Data.address = (void*)Address;

	Input_Output_Data.value = &stuff;

	Input_Output_Data.size = sizeof(Type);

	unsigned long int Readed_Bytes_Amount;

	DeviceIoControl(hDriver, ctl_write, &Input_Output_Data, sizeof Input_Output_Data, &Input_Output_Data, sizeof Input_Output_Data, &Readed_Bytes_Amount, nullptr);
}

template <typename Type>
Type DriverRead(HANDLE DriverHandle, unsigned long int ProcessId, unsigned long long int Address)
{
	info_t Input_Output_Data;

	Input_Output_Data.pid = ProcessId;

	Input_Output_Data.address = (void*)Address;

	Type Return_Value;

	Input_Output_Data.value = &Return_Value;

	Input_Output_Data.size = sizeof(Type);

	unsigned long int Readed_Bytes_Amount;

	DeviceIoControl(DriverHandle, ctl_read, &Input_Output_Data, sizeof Input_Output_Data, &Input_Output_Data, sizeof Input_Output_Data, &Readed_Bytes_Amount, nullptr);

	return *(Type*)&Return_Value;
}
