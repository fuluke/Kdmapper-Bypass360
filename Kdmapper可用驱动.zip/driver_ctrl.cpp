#include <Main_EXE/param_struct.h>
#include <include/kdmapper-1803-20h2-bytes-main/intel_driver.hpp>
#include <include/kdmapper-1803-20h2-bytes-main/driver.h>
#include <include/kdmapper-1803-20h2-bytes-main/kdmapper.hpp>
#include <include/Qant/beepDef.h>
#include <include/Qant/strpoc/qstr.h>
#include "driver_ctrl.h"

HANDLE  hDriver = 0;
extern DWORD       hProcess;
extern DWORD       dwProcessId;
extern UINT64      dwModuleBase;
void kdmapper_driver_loaded()
{
	HANDLE iqvw64e_device_handle = intel_driver::Load();

	if (!iqvw64e_device_handle || iqvw64e_device_handle == INVALID_HANDLE_VALUE)
	{
		exit(0);
	}

	if (!kdmapper::MapDriver(iqvw64e_device_handle, RawData))
	{
		intel_driver::Unload(iqvw64e_device_handle);
		exit(0);
	}

	intel_driver::Unload(iqvw64e_device_handle);
}

void driver_init(void* lpParam)
{
    hDriver = CreateFileW(L"\\\\.\\u8CI", GENERIC_READ, 0, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);

    if (hDriver == INVALID_HANDLE_VALUE)
    {
#ifdef DEBUG
        beep400hz;
        MY_PRINT_STR("Invalid DriverHandle");
#endif // DEBUG
        //Sleep(4000);
        exit(0);
    }

    info_t Input_Output_Data1;
    unsigned long int Readed_Bytes_Amount1;
    DeviceIoControl((HANDLE)hDriver, ctl_clear, &Input_Output_Data1, sizeof Input_Output_Data1, &Input_Output_Data1, sizeof Input_Output_Data1, &Readed_Bytes_Amount1, nullptr);

    info_t Input_Output_Data;
    Input_Output_Data.pid = dwProcessId;

    unsigned long int Readed_Bytes_Amount;
    DeviceIoControl((HANDLE)hDriver, ctl_base, &Input_Output_Data, sizeof Input_Output_Data, &Input_Output_Data, sizeof Input_Output_Data, &Readed_Bytes_Amount, nullptr);

    dwModuleBase = (unsigned long long int)Input_Output_Data.data;

    //std::printf("Process base address: %llX.\n", game_proc.dwModuleBase);
}


